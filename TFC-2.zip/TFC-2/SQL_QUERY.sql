CREATE DATABASE ram1;
USE ram1;

CREATE TABLE route_table (
    route_id INT PRIMARY KEY,
    route_name CHAR(100)
);

INSERT INTO route_table (route_id, route_name) VALUES
(1, 'Guntur'),
(2, 'Vijayawada'),
(3, 'Tenali'),
(4, 'Bapatla'),
(5, 'Ponnur'),
(6, 'Chilakalurpeta'),
(7, 'Chirala'),
(8, 'Narsaraopeta');


CREATE TABLE route_stops (
    stop_id INT PRIMARY KEY AUTO_INCREMENT,
    route_id INT,
    stop_name CHAR(100),
    fee_collected INT,
    FOREIGN KEY (route_id) REFERENCES route_table(route_id)
);



INSERT INTO route_stops (route_id, stop_name, fee_collected) VALUES
(1, 'Lakshmipuram', 2800),
(1, 'Kottapeta', 2700),
(1, 'Sangadegunta', 2500),
(1, 'Stadium', 2500),
(1, 'Nallapadu', 3000),
(1, 'Nallacheruvu', 3200);


INSERT INTO route_stops (route_id, stop_name, fee_collected) VALUES
(2, 'Benzcircle', 8000),
(2, 'Temple', 7900),
(2, 'Poranki', 8500),
(2, 'Amaravathi', 8200),
(2, 'Nidamanuru', 8500),
(2, 'Tadepalle', 7500);


INSERT INTO route_stops (route_id, stop_name, fee_collected) VALUES
(3, 'Chenchupeta', 1500),
(3, 'Sangamjagarlamudi', 800),
(3, 'Angalkuduru', 1000),
(3, 'Nazarpeta', 1600);


INSERT INTO route_stops (route_id, stop_name, fee_collected) VALUES
(4, 'Bapatla', 9000),
(4, 'Beachroad', 10000);


INSERT INTO route_stops (route_id, stop_name, fee_collected) VALUES
(5, 'Ponnur', 7000);


INSERT INTO route_stops (route_id, stop_name, fee_collected) VALUES
(6, 'Chilakalurpeta', 8000);


INSERT INTO route_stops (route_id, stop_name, fee_collected) VALUES
(7, 'Chirala', 12000);


INSERT INTO route_stops (route_id, stop_name, fee_collected) VALUES
(8, 'Narsaraopeta', 15000);


CREATE TABLE bus_info (
    bus_id INT PRIMARY KEY,
    route_id INT,
    bus_number CHAR(20),
    FOREIGN KEY (route_id) REFERENCES route_table(route_id)
);

INSERT INTO bus_info (bus_id, route_id, bus_number) VALUES
(1, 1, 'AP01A1234'),
(2, 2, 'AP01B5678'),
(3, 3, 'AP01C9012'),
(4, 4, 'AP01D3456'),
(5, 5, 'AP01E7890'),
(6, 6, 'AP01F1122'),
(7, 7, 'AP01G3344'),
(8, 8, 'AP01H5566');


CREATE TABLE driver_info (
    driver_id INT PRIMARY KEY,
    bus_id INT,
    driver_name CHAR(100),
    contact_number CHAR(15),
    license_number CHAR(20),
    FOREIGN KEY (bus_id) REFERENCES bus_info(bus_id)
);

INSERT INTO driver_info (driver_id, bus_id, driver_name, contact_number, license_number) VALUES
(1, 1, 'Ravi Kumar', '9876543210', 'LIC12345'),
(2, 2, 'Suresh Reddy', '8765432109', 'LIC23456'),
(3, 3, 'Manoj Babu', '7654321098', 'LIC34567'),
(4, 4, 'Anil Kumar', '6543210987', 'LIC45678'),
(5, 5, 'Ramesh Yadav', '5432109876', 'LIC56789'),
(6, 6, 'Kiran Rao', '4321098765', 'LIC67890'),
(7, 7, 'Vijay Das', '3210987654', 'LIC78901'),
(8, 8, 'Sunil Varma', '2109876543', 'LIC89012');

create table final(name text,regno text,course text,section text,dept text,stop_name text,bustype text,fee_plan text,total_fee int);
select *from final;




SELECT 
    rt.route_name,
    rs.stop_name,
    rs.fee_collected,
    bi.bus_number,
    di.driver_name,
    di.contact_number
FROM route_stops rs
JOIN route_table rt ON rs.route_id = rt.route_id
JOIN bus_info bi ON bi.route_id = rt.route_id
JOIN driver_info di ON di.bus_id = bi.bus_id
ORDER BY rt.route_name, rs.stop_name;
