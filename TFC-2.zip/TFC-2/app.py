from flask import Flask, render_template, request, send_file
import mysql.connector
from flask_cors import CORS
import pandas as pd
from io import BytesIO

app = Flask(__name__)
CORS(app)

def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='janakiram@@2005',
        database='ram1'
    )

@app.route('/')
def index():
    return render_template('index1.html')

@app.route('/calculate-add')
def add_student():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT stop_name FROM route_stops")
    stops = [row[0] for row in cursor.fetchall()]
    conn.close()
    return render_template('index.html', stops=stops)

@app.route('/calculate', methods=['POST'])
def calculate_fee():
    
    name = request.form['name']
    reg_no = request.form['reg_no']
    course = request.form['course']
    section = request.form['section']
    department = request.form['department']
    stop_name = request.form['stop_name']
    bus_type = request.form['bus_type'].lower()
    fee_plan = request.form['fee_plan'].lower()

    conn = get_db_connection()
    cursor = conn.cursor()

    
    cursor.execute("SELECT * FROM final WHERE regno = %s", (reg_no,))
    if cursor.fetchone():
        conn.close()
        return f"<h3 style='color:red;text-align:center;'>Student with Reg No {reg_no} already exists!</h3>"

    
    cursor.execute("SELECT route_id, fee_collected FROM route_stops WHERE stop_name = %s", (stop_name,))
    stop_info = cursor.fetchone()
    if not stop_info:
        conn.close()
        return "Invalid stop selected."
    route_id, fee = stop_info

    
    if bus_type == 'ac':
        fee += 6000

    
    if fee_plan == 'semester':
        fee *= 6

    
    cursor.execute("SELECT bus_number, bus_id FROM bus_info WHERE route_id = %s", (route_id,))
    bus_data = cursor.fetchone()
    if not bus_data:
        conn.close()
        return "Bus not found."
    bus_number, bus_id = bus_data

    
    cursor.execute("SELECT driver_name, contact_number, license_number FROM driver_info WHERE bus_id = %s", (bus_id,))
    driver = cursor.fetchone()
    if not driver:
        conn.close()
        return "Driver not found."
    driver_name, contact, license_no = driver

    
    cursor.execute(
        "INSERT INTO final (name, regno, course, section, dept, stop_name, bustype, fee_plan, total_fee) "
        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
        (name, reg_no, course, section, department, stop_name, bus_type, fee_plan, fee)
    )
    conn.commit()
    conn.close()

    
    return render_template(
        'receipt.html',
        name=name,
        reg_no=reg_no,
        course=course,
        section=section,
        department=department,
        stop_name=stop_name,
        bus_type=bus_type.upper(),
        fee_plan=fee_plan.upper(),
        route_id=route_id,
        bus_number=bus_number,
        driver_name=driver_name,
        contact=contact,
        license_no=license_no,
        total_fee=fee
    )

@app.route('/search-student', methods=['GET'])
def search_form():
    
    return render_template('search.html')
@app.route('/search-student', methods=['POST'])
def search_result():
    regno = request.form['regno'].strip()

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    
    cursor.execute("SELECT * FROM final WHERE regno = %s", (regno,))
    student = cursor.fetchone()

    if not student:
        conn.close()
        return "<h3 style='text-align:center;color:red;'>Student with Reg No {} not found.</h3>".format(regno)

    
    cursor.execute("SELECT route_id FROM route_stops WHERE stop_name = %s", (student['stop_name'],))
    route_row = cursor.fetchone()
    if not route_row:
        conn.close()
        return "Stop details not found."

    route_id = route_row['route_id']

    
    cursor.execute("SELECT bus_number, bus_id FROM bus_info WHERE route_id = %s", (route_id,))
    bus_row = cursor.fetchone()
    if not bus_row:
        conn.close()
        return "Bus details not found."

    bus_number = bus_row['bus_number']
    bus_id = bus_row['bus_id']

    
    cursor.execute("SELECT driver_name, contact_number, license_number FROM driver_info WHERE bus_id = %s", (bus_id,))
    driver_row = cursor.fetchone()
    if not driver_row:
        conn.close()
        return "Driver details not found."

    conn.close()

    
    context = {
        'name': student['name'],
        'reg_no': student['regno'],
        'course': student['course'],
        'section': student['section'],
        'department': student['dept'],
        'stop_name': student['stop_name'],
        'bus_type': student['bustype'].upper(),
        'fee_plan': student['fee_plan'].upper(),
        'total_fee': student['total_fee'],
        'route_id': route_id,
        'bus_number': bus_number,
        'driver_name': driver_row['driver_name'],
        'contact': driver_row['contact_number'],
        'license_no': driver_row['license_number']
    }

    return render_template('receipt.html', **context)



@app.route('/download')
def download_excel():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM final")
    rows = cursor.fetchall()
    column_names = [i[0] for i in cursor.description]
    df = pd.DataFrame(rows, columns=column_names)
    cursor.close()
    conn.close()

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='TransportFees')
    output.seek(0)

    return send_file(
        output,
        download_name="transport_fees.xlsx",
        as_attachment=True,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@app.route('/download_receipt')
def download_individual_receipt():
    name = request.args.get('name')
    regno = request.args.get('regno')

    conn = get_db_connection()
    query = "SELECT * FROM final WHERE name = %s AND regno = %s"
    df = pd.read_sql(query, conn, params=(name, regno))
    conn.close()

    if df.empty:
        return "No matching record found."

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='IndividualReceipt')
    output.seek(0)

    return send_file(
        output,
        download_name=f"{name}_receipt.xlsx",
        as_attachment=True,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

